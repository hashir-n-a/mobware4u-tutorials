Processing JavaScript Mode
==========================

This is the former ProcessingJS tool (for Processing 1.5) that became Processings internal JavaScript mode (until 2.0 beta 8) and has now been moved out of the Processing IDE.

Use *[Mode menu] --> Add Mode ...* to install into your PDE.

Tested with Processing 2.0 beta 8 or higher.
